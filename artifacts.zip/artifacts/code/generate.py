#!/usr/bin/env python3
import argparse
import csv
import json
import os
import re
import subprocess
import sys
import urllib.request

CONFIG_DIR = os.path.join(os.path.dirname(__file__), "..", "experiment_config")
OUT_DIR = os.path.join(os.path.dirname(__file__), "..", "generated_rules")
MANIFEST = os.path.join(os.path.dirname(__file__), "..", "generation_manifest.csv")

OLLAMA_URL = "http://localhost:11434/api/chat"
TEMPERATURE = 0.0
NUM_GENERATIONS = 1


# ---------- minimal YAML loader (avoids external deps on the VM) -------------
def load_yaml(path):
    try:
        import yaml
        with open(path) as f:
            return yaml.safe_load(f)
    except ImportError:
        print("PyYAML not installed. Run: pip install pyyaml --break-system-packages",
              file=sys.stderr)
        sys.exit(1)


# ---------- output cleaning --------------------------------------------------
FENCE_RE = re.compile(r"```(?:yara|yar|c)?\s*(.*?)```", re.DOTALL | re.IGNORECASE)
RULE_KW_RE = re.compile(r"(?:^|\n|\s)(rule\s+[A-Za-z_])")


def extract_rule(text):
    """Pull the YARA rule out of a model response.
    Prefers fenced blocks; else takes from the 'rule <ident>' keyword to the
    last '}'. Matches 'rule' as a whole word so 'test_rule {' is not mistaken
    for the keyword."""
    m = FENCE_RE.search(text)
    if m:
        text = m.group(1)
    km = RULE_KW_RE.search(text)
    if not km:
        return text.strip()
    start = km.start(1)
    end = text.rfind("}")
    if end == -1 or end < start:
        return text[start:].strip()
    return text[start:end + 1].strip()


# ---------- ollama call ------------------------------------------------------
def call_ollama(model, system, user):
    payload = {
        "model": model,
        "messages": [
            {"role": "system", "content": system},
            {"role": "user", "content": user},
        ],
        "stream": False,
        "options": {"temperature": TEMPERATURE},
    }
    req = urllib.request.Request(
        OLLAMA_URL,
        data=json.dumps(payload).encode(),
        headers={"Content-Type": "application/json"},
    )
    with urllib.request.urlopen(req, timeout=600) as resp:
        data = json.loads(resp.read().decode())
    return data["message"]["content"]


# ---------- compile check ----------------------------------------------------
def compile_check(rule_path):
    """Return (ok: bool, message: str). Uses yarac on a single file."""
    try:
        r = subprocess.run(
            ["yarac", "-w", rule_path, "/dev/null"],
            capture_output=True, text=True, timeout=60,
        )
        return (r.returncode == 0, (r.stderr or r.stdout).strip())
    except FileNotFoundError:
        return (False, "yarac not found on PATH")
    except subprocess.TimeoutExpired:
        return (False, "compile timeout")


def render(template, **kw):
    out = template
    for k, v in kw.items():
        out = out.replace("{" + k + "}", str(v))
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--experiment", choices=["exp1"], default="exp1")
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()

    behaviours = load_yaml(os.path.join(CONFIG_DIR, "behaviours_v1.yaml"))
    models_cfg = load_yaml(os.path.join(CONFIG_DIR, "models_v1.yaml"))
    prompts = load_yaml(os.path.join(CONFIG_DIR, "prompts_v1.yaml"))

    # Build the run matrix: all 5 models with the guided prompt (P3).
    run_models = [m["tag"] for m in models_cfg["models"]]
    run_prompts = ["P3"]

    os.makedirs(OUT_DIR, exist_ok=True)
    shared = prompts["shared"]

    rows = []
    for model in run_models:
        model_slug = model.replace(":", "_").replace(".", "")
        for pkey in run_prompts:
            p = prompts[pkey]
            for b in behaviours["behaviours"]:
                for gen_i in range(1, NUM_GENERATIONS + 1):
                    user = render(
                        p["user_template"],
                        behaviour_type=b["type"],
                        behaviour_name=b["name"],
                        behaviour_description=b["description"].strip(),
                        rule_name=b["rule_name"],
                        model_id=model,
                        generalisation_sentence=shared["generalisation_sentence"].strip(),
                        file_scope_note=shared["file_scope_note"].strip(),
                    )
                    system = p["system"].strip()

                    suffix = "" if NUM_GENERATIONS == 1 else f"_g{gen_i}"
                    stem = f"{model_slug}_{pkey}_{b['id']}{suffix}"
                    rule_path = os.path.join(OUT_DIR, stem + ".yar")

                    if args.dry_run:
                        print(f"[dry] {stem}")
                        continue

                    try:
                        raw = call_ollama(model, system, user)
                        rule_text = extract_rule(raw)
                    except Exception as e:
                        rule_text = ""
                        print(f"[ERR] {stem}: {e}", file=sys.stderr)

                    with open(rule_path, "w") as f:
                        f.write(rule_text + "\n")

                    ok, msg = compile_check(rule_path) if rule_text else (False, "empty output")
                    rows.append({
                        "stem": stem, "model": model, "prompt": pkey,
                        "behaviour_id": b["id"], "behaviour_name": b["name"],
                        "type": b["type"], "generation": gen_i,
                        "compiles": int(ok), "compile_msg": msg[:200],
                        "rule_file": os.path.relpath(rule_path),
                    })
                    print(f"[{'OK ' if ok else 'BAD'}] {stem}  {msg[:60]}")

    if rows:
        write_header = not os.path.exists(MANIFEST)
        with open(MANIFEST, "a", newline="") as f:
            w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
            if write_header:
                w.writeheader()
            w.writerows(rows)
        ok_n = sum(r["compiles"] for r in rows)
        print(f"\n{ok_n}/{len(rows)} compiled. Manifest -> {os.path.relpath(MANIFEST)}")


if __name__ == "__main__":
    main()
