#!/usr/bin/env python3

import subprocess, glob, os, sys

MAL_ROOT = "malicious_full_unpacked"
BEN_ROOT = "benign_full_unpacked"
RULES_DIR = "generated_rules"
BASELINE = "pypi_malregistry_indicators.yar"

MODELS = [
    ("llama3.2:1b",        "llama32_1b"),
    ("llama3.1:8b",        "llama31_8b"),
    ("qwen2.5-coder:7b",   "qwen25-coder_7b"),
    ("qwen2.5-coder:14b",  "qwen25-coder_14b"),
    ("gpt-oss:20b",        "gpt-oss_20b"),
]


def package_of(path, root):
    return os.path.relpath(path, root).split(os.sep)[0]


def rule_compiles(rule_file):
    return subprocess.run(
        ["yarac", "-w", rule_file, "/dev/null"],
        capture_output=True,
    ).returncode == 0


def scan_one_rule(rule_file, corpus, root):
    r = subprocess.run(
        ["yara", "-r", "-w", "-a", "30", rule_file, corpus],
        capture_output=True, text=True, timeout=14400,
    )
    matched = set()
    for line in r.stdout.splitlines():
        parts = line.split(" ", 1)
        if len(parts) == 2:
            matched.add(package_of(parts[1], root))
    return matched


def scan_ruleset(rule_files, corpus, root):
    matched = set()
    for rf in rule_files:
        if rule_compiles(rf):
            matched |= scan_one_rule(rf, corpus, root)
    return matched


def report(name, n_rules, mal, ben, mal_total, ben_total):
    det = len(mal) / mal_total * 100 if mal_total else 0
    fp = len(ben) / ben_total * 100 if ben_total else 0
    denom = len(mal) + len(ben)
    prec = len(mal) / denom if denom else 0
    print(f"{name:<24}{n_rules:>6}{det:>8.1f}%{fp:>8.1f}%{prec:>9.3f}", flush=True)


def main():
    if not os.path.isdir(MAL_ROOT):
        sys.exit(f"Missing {MAL_ROOT}. Run from the project root.")
    mal_total = len(os.listdir(MAL_ROOT))
    ben_total = len(os.listdir(BEN_ROOT))
    ratio = mal_total / ben_total if ben_total else 0
    print(f"Full corpus: {mal_total} malicious | {ben_total} benign "
          f"(ratio {ratio:.1f}:1)")
    print(f"{'model':<24}{'rules':>6}{'det%':>9}{'fp%':>9}{'prec':>9}")
    print("-" * 57)

    for tag, slug in MODELS:
        files = sorted(glob.glob(f"{RULES_DIR}/{slug}_P3_*.yar"))
        n_compiled = sum(1 for f in files if rule_compiles(f))
        mal = scan_ruleset(files, MAL_ROOT, MAL_ROOT)
        ben = scan_ruleset(files, BEN_ROOT, BEN_ROOT)
        report(tag, n_compiled, mal, ben, mal_total, ben_total)

    mal = scan_ruleset([BASELINE], MAL_ROOT, MAL_ROOT)
    ben = scan_ruleset([BASELINE], BEN_ROOT, BEN_ROOT)
    print("-" * 57)
    report("BASELINE (hand-written)", 15, mal, ben, mal_total, ben_total)


if __name__ == "__main__":
    main()
