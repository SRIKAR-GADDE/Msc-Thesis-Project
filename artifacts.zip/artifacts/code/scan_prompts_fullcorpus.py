#!/usr/bin/env python3

import subprocess, glob, os, sys

MAL_ROOT = "malicious_full_unpacked"
BEN_ROOT = "benign_full_unpacked"
RULES_DIR = "generated_rules"
MODEL_SLUG = "qwen25-coder_14b"
PROMPTS = ["P1", "P2", "P3"]


def package_of(path, root):
    return os.path.relpath(path, root).split(os.sep)[0]


def rule_compiles(rf):
    return subprocess.run(["yarac", "-w", rf, "/dev/null"],
                          capture_output=True).returncode == 0


def scan_one_rule(rf, corpus, root):
    r = subprocess.run(["yara", "-r", "-w", "-a", "30", rf, corpus],
                       capture_output=True, text=True, timeout=14400)
    m = set()
    for line in r.stdout.splitlines():
        p = line.split(" ", 1)
        if len(p) == 2:
            m.add(package_of(p[1], root))
    return m


def union(files, corpus, root):
    matched = set()
    for rf in files:
        if rule_compiles(rf):
            matched |= scan_one_rule(rf, corpus, root)
    return matched


def main():
    mal_total = len(os.listdir(MAL_ROOT))
    ben_total = len(os.listdir(BEN_ROOT))
    ratio = mal_total / ben_total if ben_total else 0
    print(f"Full corpus: {mal_total} malicious | {ben_total} benign "
          f"(ratio {ratio:.1f}:1)")
    print(f"{'prompt':<8}{'det%':>9}{'fp%':>9}{'prec':>9}   "
          f"(qwen2.5-coder:14b, rules combined)")
    print("-" * 40)
    for pkey in PROMPTS:
        files = sorted(glob.glob(f"{RULES_DIR}/{MODEL_SLUG}_{pkey}_*.yar"))
        mal = union(files, MAL_ROOT, MAL_ROOT)
        ben = union(files, BEN_ROOT, BEN_ROOT)
        det = len(mal) / mal_total * 100 if mal_total else 0
        fp = len(ben) / ben_total * 100 if ben_total else 0
        denom = len(mal) + len(ben)
        prec = len(mal) / denom if denom else 0
        print(f"{pkey:<8}{det:>8.1f}%{fp:>8.1f}%{prec:>9.3f}", flush=True)


if __name__ == "__main__":
    main()
