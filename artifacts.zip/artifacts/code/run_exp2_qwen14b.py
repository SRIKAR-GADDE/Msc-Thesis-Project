#!/usr/bin/env python3
"""
Experiment 2 (RQ2): prompt effect on qwen2.5-coder:14b.
Standalone. No flags, no config editing. Just: python3 run_exp2_qwen14b.py

Generates P1 (baseline) and P2 (analyst) rules for all 15 behaviours.
P3 already exists from Experiment 1 and is NOT regenerated.
Reads the frozen behaviour + prompt specs; ignores models_v1.yaml entirely
(the model is hardcoded below, so it does not matter what that file contains).
"""
import csv, json, os, re, subprocess, sys, urllib.request

MODEL = "qwen2.5-coder:14b"      # hardcoded — this is the whole point
PROMPTS_TO_RUN = ["P1", "P2"]    # P3 reused from exp1

CONFIG_DIR = os.path.join(os.path.dirname(__file__), "..", "experiment_config")
OUT_DIR    = os.path.join(os.path.dirname(__file__), "..", "generated_rules")
MANIFEST   = os.path.join(os.path.dirname(__file__), "..", "generation_manifest.csv")

RUN_DATE = "2026-08-04"
OLLAMA_URL = "http://localhost:11434/api/chat"
TEMPERATURE = 0.0


def load_yaml(path):
    import yaml
    with open(path) as f:
        return yaml.safe_load(f)


FENCE_RE = re.compile(r"```(?:yara|yar|c)?\s*(.*?)```", re.DOTALL | re.IGNORECASE)
RULE_KW_RE = re.compile(r"(?:^|\n|\s)(rule\s+[A-Za-z_])")

def extract_rule(text):
    m = FENCE_RE.search(text)
    if m:
        text = m.group(1)
    km = RULE_KW_RE.search(text)
    if not km:
        return text.strip()
    start = km.start(1)
    end = text.rfind("}")
    if end == -1 or end < start:
        return text[start:].strip()
    return text[start:end + 1].strip()


def call_ollama(model, system, user):
    payload = {
        "model": model,
        "messages": [{"role": "system", "content": system},
                     {"role": "user", "content": user}],
        "stream": False,
        "options": {"temperature": TEMPERATURE},
    }
    req = urllib.request.Request(
        OLLAMA_URL, data=json.dumps(payload).encode(),
        headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=600) as resp:
        return json.loads(resp.read().decode())["message"]["content"]


def compile_check(rule_path):
    try:
        r = subprocess.run(["yarac", "-w", rule_path, "/dev/null"],
                           capture_output=True, text=True, timeout=60)
        return (r.returncode == 0, (r.stderr or r.stdout).strip())
    except FileNotFoundError:
        return (False, "yarac not found on PATH")
    except subprocess.TimeoutExpired:
        return (False, "compile timeout")


def render(template, **kw):
    out = template
    for k, v in kw.items():
        out = out.replace("{" + k + "}", str(v))
    return out


def main():
    behaviours = load_yaml(os.path.join(CONFIG_DIR, "behaviours_v1.yaml"))
    prompts    = load_yaml(os.path.join(CONFIG_DIR, "prompts_v1.yaml"))
    shared     = prompts["shared"]
    os.makedirs(OUT_DIR, exist_ok=True)

    model_slug = MODEL.replace(":", "_").replace(".", "")
    print(f"Experiment 2 — model: {MODEL}  prompts: {PROMPTS_TO_RUN}")
    print(f"{len(PROMPTS_TO_RUN)} prompts x {len(behaviours['behaviours'])} behaviours "
          f"= {len(PROMPTS_TO_RUN)*len(behaviours['behaviours'])} rules\n")

    rows = []
    for pkey in PROMPTS_TO_RUN:
        p = prompts[pkey]
        for b in behaviours["behaviours"]:
            user = render(
                p["user_template"],
                behaviour_type=b["type"], behaviour_name=b["name"],
                behaviour_description=b["description"].strip(),
                rule_name=b["rule_name"], model_id=MODEL, date=RUN_DATE,
                generalisation_sentence=shared["generalisation_sentence"].strip(),
                file_scope_note=shared["file_scope_note"].strip())
            system = p["system"].strip()
            stem = f"{model_slug}_{pkey}_{b['id']}"
            rule_path = os.path.join(OUT_DIR, stem + ".yar")

            try:
                raw = call_ollama(MODEL, system, user)
                rule_text = extract_rule(raw)
            except Exception as e:
                rule_text = ""
                print(f"[ERR] {stem}: {e}", file=sys.stderr)

            with open(rule_path, "w") as f:
                f.write(rule_text + "\n")

            ok, msg = compile_check(rule_path) if rule_text else (False, "empty output")
            rows.append({
                "stem": stem, "model": MODEL, "prompt": pkey,
                "behaviour_id": b["id"], "behaviour_name": b["name"],
                "type": b["type"], "generation": 1,
                "compiles": int(ok), "compile_msg": msg[:200],
                "rule_file": os.path.relpath(rule_path),
            })
            print(f"[{'OK ' if ok else 'BAD'}] {stem}  {msg[:60]}")

    if rows:
        write_header = not os.path.exists(MANIFEST)
        with open(MANIFEST, "a", newline="") as f:
            w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
            if write_header:
                w.writeheader()
            w.writerows(rows)
        ok_n = sum(r["compiles"] for r in rows)
        print(f"\n{ok_n}/{len(rows)} compiled. Appended to {os.path.relpath(MANIFEST)}")


if __name__ == "__main__":
    main()
