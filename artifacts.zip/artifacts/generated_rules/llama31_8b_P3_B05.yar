rule pypi_dynamic_execution_api_usage {
  strings:
    $exec_import = "import.*?(exec|eval|compile)"
    $exec_call = "exec\(\s*\(.*?\)\s*\)|eval\(\s*\(.*?\)\s*\)"
    $dynamic_import = "import\s+.*?\s*\(.*?\)"
    $code_execution = "exec.*?\(.*?\)|eval.*?\(.*?\)"

  condition:
    ($exec_import or $exec_call or $dynamic_import) and
    ($code_execution)
}
