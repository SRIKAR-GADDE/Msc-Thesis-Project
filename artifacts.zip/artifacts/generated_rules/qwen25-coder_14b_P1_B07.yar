rule pypi_information_stealing_behavior {
    meta:
        description = "Detects behavior associated with collecting sensitive information such as credentials, tokens, environment variables, browser data, system information, or other locally stored secrets."
        author = "qwen2.5-coder:14b"
        date = "2026-08-04"
        reference = ""

    strings:
        $credential_patterns = /password|passwd|login|username|auth|token|secret|key/i
        $environment_vars = /os\.environ|sys\.env|getenv/i
        $system_info = /platform\..*|os\..*|sys\..*/i
        $browser_data_patterns = /cookies|history|bookmarks|cache/i

    condition:
        any of ($credential_patterns*) or any of ($environment_vars*) or any of ($system_info*) or any of ($browser_data*)
}
