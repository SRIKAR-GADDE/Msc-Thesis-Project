Meta
---
Description: Behavioural detection of platform-targeted malicious PyPI packages.
Author: llama3.2:1b
Date: 2026-08-04
Reference: -

pypi_platform_targeting_evasion
{
    type = behavior
    platform {
        any {
            os.name -eq "nt" or os.name -eq "posix"
        }
    }

    file {
        type = unknown
    }

    condition {
        $platform.os.name -eq "nt" or $platform.os.name -eq "posix"
        $os.arch -eq "x86_64" or $os.arch -eq "amd64"
    }

    action {
        skip if $os.name -eq "win32"
    }
}
