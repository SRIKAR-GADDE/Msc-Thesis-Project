rule pypi_image_steganography_evasion {
    meta:
        description = "Detects techniques where malicious payloads are hidden inside image or other non-code files, downloaded or extracted at runtime before execution."
        author = "qwen2.5-coder:14b"
        date = "2026-08-04"
        reference = ""

    strings:
        $import_pil = /from\s+PIL\s+import\s+Image/
        $open_image = /Image\.open\(/
        $decode_payload = /\.\w+\(.*\)\s*=\s*image\.getdata\(\)/

    condition:
        all of ($import_pil, $open_image, $decode_payload)
}
