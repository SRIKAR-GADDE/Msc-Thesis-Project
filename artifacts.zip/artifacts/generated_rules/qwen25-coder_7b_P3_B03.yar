rule pypi_process_api_usage {
    meta:
        description = "Detects Python APIs capable of spawning operating system processes or executing shell commands, including subprocess creation and command invocation mechanisms commonly abused by malicious packages."
        author = "qwen2.5-coder:7b"
        date = "2026-08-04"
        reference = ""

    strings:
        $subprocess = "subprocess.Popen"
        $os_system = "os.system"
        $os_spawn = "os.spawn*"
        $os_exec = "os.exec*"
        $subprocess_run = "subprocess.run"

    condition:
        any of ($subprocess, $os_system, $os_spawn, $os_exec, $subprocess_run)
}
