rule pypi_file_operation_api_usage {
    meta:
        description = "Detects suspicious use of file handling APIs in Python source code."
        author = "qwen2.5-coder:14b"
        date = "2026-08-04"
        reference = ""

    strings:
        $file_open = /open\([^,]+,\s*['"][rwxa]+\w*['"]/
        $os_remove = /os\.remove\s*\(/ nocase
        $os_rename = /os\.rename\s*\(/ nocase
        $shutil_move = /shutil\.move\s*\(/ nocase
        $subprocess_call = /subprocess\.call\s*\(/ nocase

    condition:
        any of ($file_open, $os_remove, $os_rename, $shutil_move, $subprocess_call)
}
