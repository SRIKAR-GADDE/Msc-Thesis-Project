rule pypi_file_operation_api_usage
{
    meta:
        description = "Detects suspicious file operation API usage indicative of malicious Python packages."
        author = "gpt-oss:20b"
        date = "2026-08-04"
        reference = ""

    strings:
        $os_remove      = /os\.remove/
        $os_unlink     = /os\.unlink/
        $shutil_rmtree = /shutil\.rmtree/
        $open_call     = /open\s*\(/
        $mode_w_sq     = /'w'/
        $mode_w_dq     = /"w"/
        $mode_a_sq     = /'a'/
        $mode_a_dq     = /"a"/
        $mode_b_sq     = /'b'/
        $mode_b_dq     = /"b"/
        $eval_call     = /eval\(/ 
        $exec_call     = /exec\(/ 
        $subprocess_call = /subprocess\.call/

    condition:
        (
            (any of ($os_remove, $os_unlink, $shutil_rmtree)) and
            any of ($open_call) and
            any of ($mode_w_sq, $mode_w_dq, $mode_a_sq, $mode_a_dq, $mode_b_sq, $mode_b_dq)
        )
        or
        (
            (any of ($os_remove, $os_unlink, $shutil_rmtree)) and
            any of ($eval_call, $exec_call, $subprocess_call)
        )
}
