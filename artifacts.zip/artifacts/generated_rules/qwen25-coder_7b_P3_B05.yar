rule pypi_dynamic_execution_api_usage {
    meta:
        description = "Detects Python package source code capable of dynamically executing generated or retrieved code during runtime."
        author = "qwen2.5-coder:7b"
        date = "2026-08-04"
        reference = ""

    strings:
        $exec = /exec\(/i
        $eval = /eval\(/i
        $compile = /compile\(/i
        $subprocess = /subprocess\.call\(|subprocess\.Popen\(|subprocess\.run\(/i

    condition:
        any of ($exec, $eval, $compile) and any of ($subprocess)
}
