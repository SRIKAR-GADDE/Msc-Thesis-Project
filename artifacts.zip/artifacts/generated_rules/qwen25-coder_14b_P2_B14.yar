rule pypi_trace_erasure_evasion {
    meta:
        description = "Detects attempts to remove evidence after malicious execution in Python packages."
        author = "qwen2.5-coder:14b"
        date = "2026-08-04"
        reference = ""

    strings:
        $del_files = /os\.remove\([^)]+\)/
        $rmdir = /shutil\.rmtree\([^)]+\)/
        $unlink = /os\.unlink\([^)]+\)/
        $cleanup_cmd = /\bsubprocess\.call\s*\(\s*[^,]+,\s*"rm"\s*,\s*[^)]+\s*\)/
        $tempfile_cleanup = /tempfile\.TemporaryFile\([^)]+\)\.close\(\)/
        $exec_trace_destruction = /os\.system\("rm -rf .*"\)/

    condition:
        any of ($del_files, $rmdir, $unlink, $cleanup_cmd, $tempfile_cleanup, $exec_trace_destruction)
}
