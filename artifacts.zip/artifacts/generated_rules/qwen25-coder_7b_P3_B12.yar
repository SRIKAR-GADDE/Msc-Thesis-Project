rule pypi_image_steganography_evasion {
    meta:
        description = "Detects techniques where malicious payloads are hidden inside image or other non-code files, downloaded or extracted at runtime before execution."
        author = "qwen2.5-coder:7b"
        date = "2026-08-04"
        reference = ""

    strings:
        $steganography_library = /from stegano\.(\w+) import/
        $image_loading = /Image.open\(/i
        $payload_extraction = /extract_payload\(|get_payload\(|decode_payload\(/i

    condition:
        $steganography_library and ($image_loading or $payload_extraction)
}
