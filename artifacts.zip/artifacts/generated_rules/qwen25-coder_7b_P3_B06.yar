rule pypi_command_execution_behavior {
    meta:
        description = "Detects malicious package behaviour involving execution of operating system commands, shell instructions, or external binaries after installation or during package execution."
        author = "qwen2.5-coder:7b"
        date = "2026-08-04"
        reference = ""

    strings:
        $exec_command = /os.system\(|subprocess.run\(|subprocess.Popen\(|os.popen\(|os.execve\(|os.execlp\(|os.execle\(|os.execv\(|os.execvp\(|os.execvpe\)/i
        $shell_instruction = /systemctl|service|bash -c|sh -c|cmd \/c/i

    condition:
        any of ($exec_command) or any of ($shell_instruction)
}
