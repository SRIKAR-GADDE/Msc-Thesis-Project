rule pypi_python_sandbox_escape {
    meta:
        description = "Detects techniques intended to bypass static analysis or restricted execution environments using dynamic imports, reflection, compilation, execution chains, or obfuscated runtime behaviour."
        author = "qwen2.5-coder:14b"
        date = "2026-08-04"
        reference = ""

    strings:
        $import_dynamic = /__import__\s*\(/ nocase
        $exec_code = /\beval\b\s*\(.*?\)/ nocase
        $compile_code = /\bcompile\b\s*\(.*?,\s*\'exec\'\)/ nocase
        $subprocess_call = /\bsubprocess\.Popen\b/ nocase
        $os_system_call = /\bos\.system\b/ nocase
        $os_popen_call = /\bos\.popen\b/ nocase
        $execfile_call = /\bexecfile\b/ nocase

    condition:
        any of ($import_dynamic, $exec_code, $compile_code) and (any of ($subprocess_call, $os_system_call, $os_popen_call, $execfile_call))
}
