rule pypi_remote_control_behavior {
    meta:
        description = "Detects malicious package behaviour establishing remote control functionality, including command-and-control communication channels, remote command handling, or persistent external interaction."
        author = "qwen2.5-coder:14b"
        date = "2026-08-04"
        reference = ""

    strings:
        $socket_import = /import\s+socket/
        $subprocess_import = /import\s+subprocess/
        $os_import = /import\s+os/
        $sys_import = /import\s+sys/
        $http_request = /\brequests\b\.get\(|\brequests\b\.post\(|\brequests\b\.put\(|\brequests\b\.delete\(/
        $urllib_request = /\burllib\.request\b\.urlopen\(|\burllib2\b\.urlopen\(|\burllib\b\.request\b\.Request\(|\burllib2\b\.Request\(/
        $exec_command = /subprocess\.call\(|subprocess\.check_call\(|subprocess\.Popen\(|os\.system\(|os\.popen\(|sys\.exit\(/
        $base64_decode = /\bbase64\b\.b64decode\(|\bb64decode\(/
        $eval_function = /\beval\(/
        $exec_function = /\bexec\(/
        $pickle_loads = /\bpickle\b\.loads\(|\bloads\(/
        $marshal_loads = /\bmarshal\b\.loads\(|\bloads\(/
        $json_loads = /\bjson\b\.loads\(|\bloads\(/
        $yaml_safe_load = /\byaml\b\.safe_load\(|\bsafe_load\(/
        $remote_control_pattern1 = /socket\.create_connection\([^,]+,\s*\d+\)/
        $remote_control_pattern2 = /socket\.connect\([^)]+\)/
        $remote_control_pattern3 = /socket\.sendall\([^)]+\)/
        $remote_control_pattern4 = /socket\.recv\([^)]+\)/

    condition:
        any of ($socket_import, $subprocess_import, $os_import, $sys_import) and
        (any of ($http_request, $urllib_request) or any of ($exec_command)) and
        (any of ($base64_decode, $eval_function, $exec_function, $pickle_loads, $marshal_loads, $json_loads, $yaml_safe_load)) and
        (any of ($remote_control_pattern1, $remote_control_pattern2, $remote_control_pattern3, $remote_control_pattern4))
}
