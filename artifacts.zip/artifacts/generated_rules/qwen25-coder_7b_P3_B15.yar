rule pypi_platform_targeting_evasion {
    meta:
        description = "Detects malicious packages that identify the operating system platform and execute platform-specific payloads or behaviour targeting Windows, Linux, or macOS environments."
        author = "qwen2.5-coder:7b"
        date = "2026-08-04"
        reference = ""

    strings:
        $platform_check = /platform.system\(\)/
        $os_specific_code = /(import|from)\s+os\s+(as\s+\w+)?\s*;?\s*(if\s+platform.system\(\)\s*==\s*"Windows"\s*\{[^}]*\}|if\s+platform.system\(\)\s*==\s*"Linux"\s*\{[^}]*\}|if\s+platform.system\(\)\s*==\s*"Darwin"\s*\{[^}]*\})/

    condition:
        $platform_check and $os_specific_code
}
