rule pypi_trace_erasure_evasion {
    meta:
        description = "Detects attempts to remove evidence after malicious execution, including deletion of dropped files, cleanup commands, temporary payload removal, or destruction of execution traces."
        author = "qwen2.5-coder:7b"
        date = "2026-08-04"
        reference = ""

    strings:
        $str1 = "rm -rf"
        $str2 = "del /f /q"
        $str3 = "os.remove("
        $str4 = "shutil.rmtree("

    condition:
        any of ($str*) and
        filesize < 10MB and
        not any of (pe, elf)
}
