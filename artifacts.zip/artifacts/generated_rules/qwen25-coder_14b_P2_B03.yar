rule pypi_process_api_usage {
    meta:
        description = "Detects Python APIs capable of spawning operating system processes or executing shell commands."
        author = "qwen2.5-coder:14b"
        date = "2026-08-04"
        reference = ""

    strings:
        $subprocess_popen = /subprocess\.Popen\(/ nocase
        $os_system = /os\.system\(/ nocase
        $os_spawnl = /os\.spawnl\(/ nocase
        $os_spawnv = /os\.spawnv\(/ nocase
        $os_execvp = /os\.execvp\(/ nocase
        $os_execl = /os\.execl\(/ nocase
        $os_execle = /os\.execle\(/ nocase
        $os_execvpe = /os\.execvpe\(/ nocase
        $os_startfile = /os\.startfile\(/ nocase
        $shutil_which = /shutil\.which\(/ nocase

    condition:
        any of ($subprocess_popen, $os_system, $os_spawnl, $os_spawnv, $os_execvp, $os_execl, $os_execle, $os_execvpe, $os_startfile, $shutil_which)
}
