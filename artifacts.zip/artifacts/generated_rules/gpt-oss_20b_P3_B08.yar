rule pypi_unauthorized_file_operation_behavior
{
    meta:
        description = "Detects malicious file manipulation behaviour in Python packages"
        author="gpt-oss:20b"
        date="2026-08-04"
        reference=""
    strings:
        // Opening files for writing (text or binary)
        $open_write  = /open\(.*[\'"]w[\'"]/ nocase
        $open_write_bin = /open\(.*[\'"]wb[\'"]/ nocase

        // Deleting or unlinking files
        $os_remove   = /\bos\.remove\(/ nocase
        $os_unlink   = /\bos\.unlink\(/ nocase

        // Copying or moving files
        $shutil_copy = /\bshutil\.copy\b/ nocase
        $shutil_move = /\bshutil\.move\b/ nocase

        // Path traversal or absolute path usage
        $path_traversal = /(\.\./|\/)/ nocase

        // Shell-based removal (e.g., rm -rf)
        $rm_rf       = /\bos\.system\(.*[\'"]rm\s+-rf[\'"]/ nocase

    condition:
        (
            (($open_write or $open_write_bin) and
             ($os_remove or $os_unlink or $shutil_copy or $shutil_move) and
             $path_traversal)
        ) or
        ($rm_rf and $path_traversal)
}
