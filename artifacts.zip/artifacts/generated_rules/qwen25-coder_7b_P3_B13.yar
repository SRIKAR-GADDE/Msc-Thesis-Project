rule pypi_python_sandbox_escape {
    meta:
        description = "Detects Python packages attempting to escape restricted execution environments using dynamic imports, reflection, compilation, or obfuscated runtime behaviour."
        author = "qwen2.5-coder:7b"
        date = "2026-08-04"
        reference = ""

    strings:
        $a = "import "
        $b = "exec(" 
        $c = "compile("
        $d = "__import__"
        $e = "eval("

    condition:
        any of ($a, $b, $c, $d, $e) and not any of (".py", ".ipynb")
}
