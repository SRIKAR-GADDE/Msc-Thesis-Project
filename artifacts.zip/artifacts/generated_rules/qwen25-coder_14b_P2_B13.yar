rule pypi_python_sandbox_escape {
    meta:
        description = "Detects techniques intended to bypass static analysis or restricted execution environments using dynamic imports, reflection, compilation, execution chains, or obfuscated runtime behaviour."
        author = "qwen2.5-coder:14b"
        date = "2026-08-04"
        reference = ""

    strings:
        $dynamic_imports = /__import__\([^)]+\)/
        $reflection = /\.__getattr__\(/ or /\.__getattribute__\(/
        $compilation = /compile\([^)]+\)/
        $execution_chain = /exec\([^)]+\)|eval\([^)]+\)/
        $obfuscation = /\.\w+\(\)\.\w+\(\)/

    condition:
        any of ($dynamic_imports, $reflection, $compilation, $execution_chain, $obfuscation)
}
