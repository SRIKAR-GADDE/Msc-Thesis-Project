rule pypi_network_api_usage {
    meta:
        description = "Detects Python package source code that uses networking capabilities to communicate with external servers."
        author = "qwen2.5-coder:14b"
        date = "2026-08-04"
        reference = ""

    strings:
        $http_client_import = /import\s+requests/
        $socket_import = /import\s+socket/
        $urllib_import = /import\s+urllib\./
        $http_request_pattern = /\brequests\.get\b|\brequests\.post\b|\brequests\.put\b|\brequests\.delete\b/
        $socket_connect_pattern = /\bsocket\.connect\b/
        $urlopen_pattern = /\burllib\.request\.urlopen\b/

    condition:
        ($http_client_import or $socket_import or $urllib_import) and
        ($http_request_pattern or $socket_connect_pattern or $urlopen_pattern)
}
