rule pypi_python_sandbox_escape {
    meta:
        description = "Detects Python sandbox escape behaviour via dynamic imports, eval/exec, and obfuscated runtime"
        author = "gpt-oss:20b"
        date = "2026-08-04"
        reference = ""
    strings:
        $dynamic_import1   = /__import__\s*\(.*\)/ nocase
        $dynamic_import2   = /importlib\.import_module\s*\(.*\)/ nocase
        $exec_eval_compile = /(eval|exec|compile)\s*\(.*\)/ nocase
        $ast_parse         = /ast\.parse\s*\(.*\)/ nocase
        $types_func        = /types\.FunctionType\s*\(.*\)/ nocase
        $sys_modules       = /sys\.modules\s*\[.*\]/ nocase
    condition:
        (count($dynamic_import1) + count($dynamic_import2) > 0)
        and (
            (count($exec_eval_compile) + count($ast_parse) + count($types_func) > 0)
            or count($sys_modules) > 0
        )
}
