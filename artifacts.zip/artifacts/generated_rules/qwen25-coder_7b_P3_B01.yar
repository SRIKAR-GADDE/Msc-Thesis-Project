rule pypi_network_api_usage {
    meta:
        description = "Detects Python package source code that uses networking capabilities to communicate with external servers."
        author = "qwen2.5-coder:7b"
        date = "2026-08-04"
        reference = ""

    strings:
        $http_client = /requests\.get|requests\.post|requests\.put|requests\.delete/
        $socket_communication = /socket\.create_connection|socket\.connect/
        $url_request = /urllib\.request\.urlopen/
        $remote_connection = /paramiko\.client\.SSHClient/

    condition:
        any of ($http_client, $socket_communication, $url_request, $remote_connection)
}
