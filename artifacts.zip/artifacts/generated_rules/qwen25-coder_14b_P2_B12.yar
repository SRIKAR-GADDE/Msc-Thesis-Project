rule pypi_image_steganography_evasion {
    meta:
        description = "Detects techniques where malicious payloads are hidden inside image or other non-code files, downloaded or extracted at runtime before execution."
        author = "qwen2.5-coder:14b"
        date = "2026-08-04"
        reference = ""

    strings:
        $import_pil = /from\s+PIL\s+import\s+(Image|PngImagePlugin)/
        $import_stegano = /from\s+stegano\s+import\s+(lsb|exif)/
        $image_download = /\brequests\.get\([^,]+,\s*stream=True\b/
        $extract_payload = /\bopen\([^,]+\)\.write\(.*\.content\)/
        $decode_image = /\bImage\.open\([^)]+\)\.convert\('RGB'\)/
        $hide_payload = /\bencode_message\s*\(/  // Assuming a common function name for hiding messages

    condition:
        all of ($import_pil, $image_download, $extract_payload, $decode_image) or
        any of ($import_stegano, $hide_payload)
}
