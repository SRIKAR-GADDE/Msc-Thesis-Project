rule pypi_image_steganography_evasion
{
    meta:
        description = "Detects malicious Python packages that hide payloads inside images and execute them at runtime."
        author = "gpt-oss:20b"
        date = "2026-08-04"
        reference = ""

    strings:
        $open_image_file   = /open\(['"].*\.(png|jpg|jpeg|bmp)['"]/ nocase
        $import_pil        = /from\s+PIL\.Image\s+import\s+open|import\s+PIL\.Image/ nocase
        $import_requests   = /import\s+requests|from\s+urllib\.request\s+import\s+urlopen|import\s+urllib.request/ nocase
        $download_image    = /requests\.get\(|urllib.request.urlopen\(/ nocase
        $base64_decode     = /b64decode\(|base64\.b64decode\( / nocase
        $zlib_decompress   = /zlib\.decompress\( / nocase
        $exec_call         = /exec\(/ nocase
        $eval_call         = /eval\(/ nocase
        $io_bytesio        = /BytesIO\(/ nocase

    condition:
        // Must open or download an image file
        ($open_image_file or $download_image)
        and (
            // Either base64 decode or zlib decompress is used
            ($base64_decode or $zlib_decompress)
            // And the decoded data is executed
            and ($exec_call or $eval_call)
        )
}
