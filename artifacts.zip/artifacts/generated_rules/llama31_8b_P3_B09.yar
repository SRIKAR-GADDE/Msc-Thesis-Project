rule pypi_code_execution_behavior {
  strings:
    $eval_import = "import.*?eval\("
    $exec_import = "import.*?exec\("
    $exec_func   = "exec\(.*?\)"
    $eval_func   = "eval\(.+\)"
    $dynamic_eval = "compile\(.+\)"
    $dynamic_exec = "exec\(compile\(.+\))"
  condition:
    any of them
}
