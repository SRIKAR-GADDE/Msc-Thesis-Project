rule pypi_dynamic_execution_api_usage {
    meta:
        description = "Detects Python package source code capable of dynamically executing generated or retrieved code during runtime."
        author = "qwen2.5-coder:14b"
        date = "2026-08-04"
        reference = ""

    strings:
        $dynamic_exec_1 = /exec\(/ nocase
        $dynamic_exec_2 = /eval\(/ nocase
        $dynamic_exec_3 = /compile\(/ nocase

    condition:
        any of ($dynamic_exec*)
}
