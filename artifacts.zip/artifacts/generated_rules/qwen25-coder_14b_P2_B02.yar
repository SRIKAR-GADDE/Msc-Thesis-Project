rule pypi_file_operation_api_usage {
    meta:
        description = "Detects suspicious use of file handling APIs that may allow malicious packages to read, modify, create, or delete local files."
        author = "qwen2.5-coder:14b"
        date = "2026-08-04"
        reference = ""

    strings:
        $file_read = /open\([^,]+,\s*['"]r['"]/i
        $file_write = /open\([^,]+,\s*['"]w['"]/i
        $file_append = /open\([^,]+,\s*['"]a['"]/i
        $file_delete = /os\.remove\(/i
        $file_rename = /os\.rename\(/i
        $subprocess_call = /subprocess\.call\(/i
        $subprocess_popen = /subprocess\.Popen\(/i

    condition:
        (2 of ($file_read, $file_write, $file_append)) and (1 of ($file_delete, $file_rename)) and (1 of ($subprocess_call, $subprocess_popen))
}
