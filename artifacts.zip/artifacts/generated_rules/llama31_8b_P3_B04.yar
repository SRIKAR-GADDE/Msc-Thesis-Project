rule pypi_encoding_obfuscation_api_usage:
  meta:
    description = "Detects encoding, decoding, encryption or transformation functions commonly used to conceal malicious payloads, commands or downloaded content inside Python packages."
    author      = "llama3.1:8b"
    date        = "2026-08-04"
    reference   = ""

  strings:
    $base64_decode = /import base64|base64\.decode\(/
    $base64_encode = /base64\.encode\(|base64\.b64encode\(|base64\.b64decode\(
    $hashlib       = /import hashlib|hashlib\.sha1|hashlib\.md5|hashlib\.sha256|hashlib\.sha512/
    $hmac          = /import hmac|hmac\.new|hmac\.compare_digest/
    $urllib        = /import urllib|urllib\.parse\(|urllib\.unquote\(|urllib\.urlretrieve\(
    $gzip          = /import gzip|gzip\.GzipFile|gzip\.decompress\(|gzip\.compress\(
    $lzma          = /import lzma|lzma\.open\(|lzma\.decompress\(|lzma\.compress\(
    $zlib          = /import zlib|zlib\.decompress\(|zlib\.compress\(|zlib\.crc32\(
    $zip           = /import zipfile|zipfile\.ZipFile|zipfile\.read\(|zipfile\.extract\(
    $tar           = /import tarfile|tarfile\.TarFile|tarfile\.extractfile\(|tarfile\.extract\(
    $bz2           = /import bz2|bz2\.decompress\(|bz2\.compress\(|bz2\.crc32\(
    $sha1          = /import sha|sha\.new|sha\.update|sha\.hexdigest/
    $aes           = /import hashlib|hashlib\.aead\_algorithm|hashlib\.AES\_cipher/
    $des           = /import DES|des\.crypt|des\.decrypt/

  condition:
    any of them
