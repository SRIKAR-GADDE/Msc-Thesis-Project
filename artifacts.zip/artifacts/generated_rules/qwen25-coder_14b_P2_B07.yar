rule pypi_information_stealing_behavior {
    meta:
        description = "Detects behaviour associated with collecting sensitive information such as credentials, tokens, environment variables, browser data, system information, or other locally stored secrets."
        author = "qwen2.5-coder:14b"
        date = "2026-08-04"
        reference = ""

    strings:
        $env_var_access = /os\.environ\[[^]]+\]/
        $credential_access = /\b(getpass|keyring)\.\w+\(/ nocase
        $token_access = /(\btoken\b|\bauth_token\b)/ nocase
        $browser_data_access = /(\bselenium\b|\bpyppeteer\b|\bsplinter\b)/ nocase
        $system_info_access = /\bplatform\.(uname|node)\(/ nocase
        $secret_file_read = /open\(['\"](.*\.env|.*\.ini|.*\.cfg|.*\.json)[\"'], 'r'\)/ nocase

    condition:
        any of ($*)
}
