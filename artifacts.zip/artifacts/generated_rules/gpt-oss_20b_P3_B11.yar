rule pypi_indirect_import_evasion
{
    meta:
        description = "Detects malicious behaviour where harmful functionality is introduced through package dependencies, installation hooks, or indirect imports."
        author = "gpt-oss:20b"
        date = "2026-08-04"
        reference = ""

    strings:
        $setup_cmdclass   = /setup\s*\(\s*.*cmdclass\s*:\s*\{[^}]*install\s*:\s*[A-Za-z_][A-Za-z0-9_]*\s*\}/si
        $custom_class     = /class\s+[A-Za-z_][A-Za-z0-9_]*\(.*(?:setuptools\.Command|distutils\.cmd\.Command).*?\)/si
        $run_importlib    = /def\s+run\s*\(\s*self\s*\)\s*:.*importlib\.import_module\([^)]*\)/si
        $run_pkgresources = /def\s+run\s*\(\s*self\s*\)\s*:.*pkg_resources\.require\([^)]*\)/si
        $dynamic_import   = /(importlib\.import_module|__import__)\([^)]*\)/si

    condition:
        (
            ($setup_cmdclass and $custom_class) or
            $run_importlib or
            $run_pkgresources
        ) and
        $dynamic_import
}
