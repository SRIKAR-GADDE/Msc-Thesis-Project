rule pypi_remote_control_behavior
{
    meta:
        description = "Detects malicious Python packages establishing remote control functionality"
        author = "gpt-oss:20b"
        date = "2026-08-04"
        reference = ""

    strings:
        // Network connection patterns
        $net_socket      = /socket\.socket/i
        $net_http        = /requests\./i
        $net_urllib      = /urllib\.request/i
        $net_websockets  = /websockets\./i
        $net_telnet      = /telnetlib\./i

        // Command execution patterns
        $cmd_subprocess  = /subprocess\.Popen|os\.system|os\.popen|subprocess\.call|subprocess\.run/i
        $cmd_eval_exec   = /eval\(|exec\(/i

        // Remote command handling loop
        $loop_recv       = /recv\(.*?\)/i
        $loop_read       = /read\(.*?\)/i

        // Thread or async listening
        $thread_start    = /threading\.Thread|asyncio\.create_task|start_server/i

    condition:
        (
            (any of ($net_socket, $net_http, $net_urllib, $net_websockets, $net_telnet))
            and
            any of ($cmd_subprocess, $cmd_eval_exec)
            and
            any of ($loop_recv, $loop_read)
            and
            any of ($thread_start)
        )
}
