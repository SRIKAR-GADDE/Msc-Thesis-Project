Meta
---
Description: Behavioural detection of malicious package execution in PyPI packages
Author: llama3.2:1b
Date: 2026-08-04
Reference: None

pypi_command_execution_behavior
{
    type = behavior
    category = commandExecution
    description:
        "Detects malicious package behaviour involving OS command execution, shell instructions, or external binaries after installation or during package execution."
}
