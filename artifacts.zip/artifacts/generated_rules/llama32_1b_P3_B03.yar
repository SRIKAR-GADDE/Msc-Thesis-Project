Meta
-----
Description
---------
Detects Python APIs capable of spawning operating system processes or executing shell commands.

Author
------
lama3.2:1b

Date
----
2026-08-04

Reference
----------
N/A
