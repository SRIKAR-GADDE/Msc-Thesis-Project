Meta
-----
Description
---------
Detects execution of injected, downloaded, or dynamically generated Python code through runtime evaluation or execution mechanisms.

Author
------
lama3.2:1b

Date
----
2026-08-04
