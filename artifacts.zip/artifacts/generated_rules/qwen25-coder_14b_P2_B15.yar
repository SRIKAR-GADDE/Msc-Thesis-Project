rule pypi_platform_targeting_evasion {
    meta:
        description = "Detects malicious packages that identify the operating system platform and execute platform-specific payloads or behaviour targeting Windows, Linux, or macOS environments."
        author = "qwen2.5-coder:14b"
        date = "2026-08-04"
        reference = ""

    strings:
        $platform_check_win = /sys.platform.*win32/i
        $platform_check_linux = /sys.platform.*linux/i
        $platform_check_macos = /sys.platform.*darwin/i
        $subprocess_call = /subprocess\.call\(/i
        $os_system_call = /os\.system\(/i

    condition:
        any of ($platform_check*) and (any of ($subprocess_call, $os_system_call))
}
