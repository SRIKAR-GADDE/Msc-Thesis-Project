Meta
---
Description: API usage detection for encoding, decoding, encryption, or transformation functions.
Author: llama3.2:1b
Date: 2026-08-04
Reference: None

pypi_encoding_obfuscation_api_usage
{
    type = behavioral
    source 
        {
            apiUsage 
                {
                    encDecEncryptTransform 
                        {
                            apiCall 
                                {
                                    function = "encode"
                                    inputType = "bytes"
                                    outputType = "bytes"
                                }
                            function = "decode"
                            inputType = "bytes"
                            outputType = "string"
                        }
                    encDecEncryptTransform 
                        {
                            apiCall 
                                {
                                    function = "encrypt"
                                    inputType = "bytes"
                                    outputType = "bytes"
                                }
                            function = "decrypt"
                            inputType = "bytes"
                            outputType = "bytes"
                        }
                    encDecEncryptTransform 
                        {
                            apiCall 
                                {
                                    function = "transform"
                                    inputType = "string"
                                    outputType = "string"
                                }
                            function = "decode"
                            inputType = "bytes"
                            outputType = "string"
                        }
                }
            apiUsage 
                {
                    encryption 
                        {
                            apiCall 
                                {
                                    function = "encrypt"
                                    inputType = "string"
                                    outputType = "string"
                                }
                            function = "decrypt"
                            inputType = "string"
                            outputType = "string"
                        }
                    decryption 
                        {
                            apiCall 
                                {
                                    function = "decrypt"
                                    inputType = "string"
                                    outputType = "string"
                                }
                            function = "encrypt"
                            inputType = "string"
                            outputType = "string"
                        }
                }
        }
}
