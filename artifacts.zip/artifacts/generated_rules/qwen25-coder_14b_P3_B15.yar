rule pypi_platform_targeting_evasion {
    meta:
        description = "Detects malicious packages that identify the operating system platform and execute platform-specific payloads or behaviour targeting Windows, Linux, or macOS environments."
        author = "qwen2.5-coder:14b"
        date = "2026-08-04"
        reference = ""

    strings:
        $platform_check_1 = "sys.platform.startswith('win')"
        $platform_check_2 = "sys.platform.startswith('linux')"
        $platform_check_3 = "sys.platform.startswith('darwin')"

        $os_module_import = "import os"
        $subprocess_module_import = "import subprocess"

        $shell_exec_1 = "os.system("
        $shell_exec_2 = "subprocess.call("

    condition:
        ($platform_check_* and ($os_module_import or $subprocess_module_import) and ($shell_exec_*))
}
