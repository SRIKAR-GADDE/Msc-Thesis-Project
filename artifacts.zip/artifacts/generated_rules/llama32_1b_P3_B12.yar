Meta
-----
Description
---------
Detects image steganography payloads hidden in PyPI packages.

Author
------
lama3.2:1b

Date
----
2026-08-04

Reference
----------
N/A
