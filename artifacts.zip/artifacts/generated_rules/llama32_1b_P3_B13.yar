Meta
-----
Description
---------
Detects behavioural patterns indicative of sandbox escape attempts in Python packages.

Author
------
lama3.2:1b

Date
----
2026-08-04

Reference
----------
N/A
