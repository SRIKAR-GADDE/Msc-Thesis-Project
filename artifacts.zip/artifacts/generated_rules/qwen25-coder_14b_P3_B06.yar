rule pypi_command_execution_behavior {
    meta:
        description = "Detects malicious package behaviour involving execution of operating system commands, shell instructions, or external binaries after installation or during package execution."
        author = "qwen2.5-coder:14b"
        date = "2026-08-04"
        reference = ""

    strings:
        $subprocess_call = /subprocess\.(call|check_call|check_output|run)\(/ nocase
        $os_system_call = /os\.system\(/ nocase
        $popen_call = /subprocess\.Popen\(/ nocase
        $shell_equals_true = /\bshell\s*=\s*True\b/ nocase

    condition:
        any of ($subprocess_call, $os_system_call, $popen_call) and $shell_equals_true
}
