rule pypi_image_steganography_evasion {
  strings:
    $image_extension = "jpg|png|gif|bmp|tiff|ico"
    $file_open_api = "open\(|os\.open\(|io\.open\("
    $read_api = "read\(|os\.read\(|io\.read\("
    $decode_api = "decode\(|base64\.b85decode\(|base64\.b16decode\(|base64\.b32decode"
    $stegano_api = "py\_stego|steganography|hide\_data|extract\_data"

  condition:
    any of them
      ($image_extension and $file_open_api and $read_api)
      ($image_extension and $decode_api and $stegano_api)
}
