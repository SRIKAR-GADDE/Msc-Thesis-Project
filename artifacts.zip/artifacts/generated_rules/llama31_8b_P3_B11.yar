rule pypi_indirect_import_evasion:
  strings:
    $import_hook = /__import__/i
    $module_search = /\.\./i
    $package_search = /[a-zA-Z_][a-zA-Z0-9_.]*\.find_module\(/i
    $sys_path_modification = /sys\.path\.append/i or /sys\.path\.insert/i

  condition:
    any of them
