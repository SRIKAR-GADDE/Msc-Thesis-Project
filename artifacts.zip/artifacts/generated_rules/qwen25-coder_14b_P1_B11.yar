rule pypi_indirect_import_evasion {
    meta:
        description = "Detects malicious behaviour where harmful functionality is introduced through package dependencies, installation hooks, or indirect imports instead of being directly contained in the main package source."
        author = "qwen2.5-coder:14b"
        date = "2026-08-04"
        reference = ""

    strings:
        $indirect_import = /__import__\([^)]+\)/
        $install_hook = /\bsetuptools\.setup\s*\([^)]*entry_points\s*=\s*[^}]*console_scripts\b/
        $post_install_script = /def\s+post_install\s*\(/

    condition:
        any of ($indirect_import, $install_hook, $post_install_script)
}
