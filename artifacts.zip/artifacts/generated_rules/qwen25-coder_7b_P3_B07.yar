rule pypi_information_stealing_behavior {
    meta:
        description = "Detects behaviour associated with collecting sensitive information such as credentials, tokens, environment variables, browser data, system information, or other locally stored secrets."
        author = "qwen2.5-coder:7b"
        date = "2026-08-04"
        reference = ""

    strings:
        $s1 = "getpass"
        $s2 = "os.environ"
        $s3 = "requests.get"
        $s4 = "subprocess.run"
        $s5 = "webbrowser.open"

    condition:
        any of ($s*) and
        (file.type == "python" or file.type == "script")
}
