rule pypi_unauthorized_file_operation_behavior {
    meta:
        description = "Detects unauthorized file manipulation behavior in Python source code."
        author = "qwen2.5-coder:14b"
        date = "2026-08-04"
        reference = ""

    strings:
        $read = /open\([^,]+,\s*['"]r['"]/ nocase
        $write = /open\([^,]+,\s*['"]w['"]/ nocase
        $append = /open\([^,]+,\s*['"]a['"]/ nocase
        $os_read = /os\.read\(.*\)/ nocase
        $os_write = /os\.write\(.*\)/ nocase
        $os_remove = /os\.remove\(.*\)/ nocase
        $os_rename = /os\.rename\(.*\)/ nocase
        $shutil_copy = /shutil\.copy\(.*\)/ nocase
        $shutil_move = /shutil\.move\(.*\)/ nocase

    condition:
        any of ($read, $write, $append, $os_read, $os_write, $os_remove, $os_rename, $shutil_copy, $shutil_move)
}
