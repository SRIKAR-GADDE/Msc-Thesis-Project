Meta
-----
Description
---------
Detect indirect import dependency abuse in PyPI packages.

Author
------
lama3.2:1b

Date
----
2026-08-04

Reference
----------
None
