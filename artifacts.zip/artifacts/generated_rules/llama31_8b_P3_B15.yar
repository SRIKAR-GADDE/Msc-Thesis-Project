rule pypi_platform_targeting_evasion {
    meta:
        description = "Detects malicious packages that identify the operating system platform and execute platform-specific payloads or behaviour targeting Windows, Linux, or macOS environments."
        author = "llama3.1:8b"
        date = "2026-08-04"
        reference = ""

    strings:
        $pypi_imports_count = pypi_imports_count
        $os_detection_count = os_detection_count
        $payload_execution_count = payload_execution_count

    condition:
        ($pypi_imports_count > 2) and
        (any of ($os_detection_count > 1)) and
        (any of ($payload_execution_count > 1))
}
