Meta
-----
Description
---------
Detects malicious file manipulation behaviour including unauthorized reading, writing, modification, copying, or deletion of local files.

Author
------
lama3.2:1b

Date
----
2026-08-04

Reference
----------
None
