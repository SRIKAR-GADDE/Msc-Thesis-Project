rule pypi_trace_erasure_evasion
{
    meta:
        description = "Detects attempts to remove evidence after malicious execution, including deletion of dropped files, cleanup commands, temporary payload removal, or destruction of execution traces."
        author = "gpt-oss:20b"
        date = "2026-08-04"
        reference =
