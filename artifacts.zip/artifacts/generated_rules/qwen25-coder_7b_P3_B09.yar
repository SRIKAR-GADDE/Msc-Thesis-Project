rule pypi_code_execution_behavior {
    meta:
        description = "Detects execution of injected, downloaded, or dynamically generated Python code through runtime evaluation or execution mechanisms."
        author = "qwen2.5-coder:7b"
        date = "2026-08-04"
        reference = ""

    strings:
        $exec1 = { 6a 00 59 b8 00 00 00 00 ba 00 00 00 00 cd 80 }
        $exec2 = { 31 c0 50 68 2f 2f 73 68 68 2f 62 69 6e 89 e3 50 53 89 e1 b0 0b cd 80 }
        $exec3 = { 48 31 c0 48 31 d2 48 b8 3b 00 00 00 00 0f 05 }

    condition:
        any of ($exec*)
}
