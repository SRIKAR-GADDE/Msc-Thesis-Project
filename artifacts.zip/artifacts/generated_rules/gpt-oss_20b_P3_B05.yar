rule pypi_dynamic_execution_api_usage
{
    meta:
        description = "Detects Python packages that dynamically execute code during runtime"
        author = "gpt-oss:20b"
        date = "2026-08-04"
        reference = ""

    strings:
        $eval          = /eval\s*\(/ nocase
        $exec          = /exec\s*\(/ nocase
        $compile       = /compile\s*\(/ nocase

        $os_system     = /os\.system\s*\(/ nocase
        $subprocess_popen_shell = /subprocess\.Popen\s*\(.*shell\s*=\s*true/i
        $importlib_dynamic  = /importlib\.import_module\s*\(\s*[^\)]+/i
        $execfile_py2   = /execfile\s*\(/ nocase

    condition:
        (
            (any of ($eval, $exec, $compile)) and
            (any of ($os_system, $subprocess_popen_shell, $importlib_dynamic, $execfile_py2))
        )
}
