rule pypi_code_execution_behavior
{
    meta:
        description = "Detects dynamic code execution in Python packages"
        author = "gpt-oss:20b"
        date = "2026-08-04"
        reference = ""

    strings:
        $exec = /exec\s*\(/
        $eval = /eval\s*\(/
        $compile = /compile\s*\(/
        $importlib_import_module = /importlib\.import_module\s*\(/
        $__import__ = /__import__\s*\(/
        $os_system = /os\.system\s*\(/
        $subprocess_popen = /subprocess\.Popen\s*\(/
        $regex_exec_compile = /exec\s*\(\s*compile\s*\(/
        $regex_eval_compile = /eval\s*\(\s*compile\s*\(/

    condition:
        (
            (any of ($exec, $eval, $compile)) and
            any of ($importlib_import_module, $__import__, $os_system, $subprocess_popen)
        )
        or
        any of ($regex_exec_compile, $regex_eval_compile)
}
