rule pypi_encoding_obfuscation_api_usage {
    meta:
        description = "Detects encoding, decoding, encryption, or transformation functions commonly used to conceal malicious payloads, commands, or downloaded content inside Python packages."
        author = "qwen2.5-coder:14b"
        date = "2026-08-04"
        reference = ""

    strings:
        $base64_encode = /base64\.encode\(/ nocase
        $base64_decode = /base64\.decode\(/ nocase
        $gzip_compress = /gzip\.compress\(/ nocase
        $gzip_decompress = /gzip\.decompress\(/ nocase
        $zlib_compress = /zlib\.compress\(/ nocase
        $zlib_decompress = /zlib\.decompress\(/ nocase
        $aes_encrypt = /AES\.encrypt\(/ nocase
        $aes_decrypt = /AES\.decrypt\(/ nocase
        $xor_cipher = /\^\s*0x[0-9a-fA-F]+/ nocase

    condition:
        (2 of ($base64*)) or
        (2 of ($gzip*)) or
        (2 of ($zlib*)) or
        (2 of ($aes*)) or
        $xor_cipher
}
