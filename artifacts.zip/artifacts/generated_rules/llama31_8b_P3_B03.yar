$pypi_process_api_usage =
  (subprocess or os or commands or popen or call or system) and
  (
    exec or fork or spawn or create_process or process or thread or run or start
  ) and not (
    __import__ == "imp" or __import__ == "importlib"
  )

meta:
  description = "Detects Python APIs capable of spawning operating system processes or executing shell commands."
  author="llama3.1:8b"
  date="2026-08-04"
  reference=""
