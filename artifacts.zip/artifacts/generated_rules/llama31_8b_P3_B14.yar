rule pypi_trace_erasure_evasion
{
    meta:
        description = "Detects attempts to remove evidence after malicious execution in PyPI packages."
        author = "llama3.1:8b"
        date = "2026-08-04"
        reference = ""

    strings:
        $cleanup_cmd = /import.*?(shutil|tempfile|os).*(remove|delete).*?/
        $drop_file = /open\(\s*["']?tmp["']?\s*\).*(write|read).*?/
        $exec_trace = /import.*?(psutil|pympler|traceback).*(process|memory).*?/

    condition:
        any of them
}
