rule pypi_remote_control_behavior {
    meta:
        description = "Detects malicious package behaviour establishing remote control functionality, including command-and-control communication channels, remote command handling, or persistent external interaction."
        author = "qwen2.5-coder:14b"
        date = "2026-08-04"
        reference = ""

    strings:
        $socket_import = /import\s+socket/
        $subprocess_import = /import\s+subprocess/
        $os_import = /import\s+os/
        $sys_import = /import\s+sys/
        $http_request = /\brequests\b\.get\(/
        $urllib_request = /\burllib\.request\.urlopen\(/
        $socket_connect = /socket\.connect\(/
        $subprocess_popen = /subprocess\.Popen\(/
        $os_system = /os\.system\(/
        $sys_exit = /sys\.exit\(/
        $base64_decode = /\bbase64\b\.b64decode\(/
        $exec_command = /\bexec\(/

    condition:
        (2 of ($socket_* and $subprocess_*) or 3 of ($http_request, $urllib_request, $socket_connect) or 2 of ($os_system, $sys_exit)) and 
        any of ($base64_decode, $exec_command)
}
