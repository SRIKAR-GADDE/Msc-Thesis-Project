rule pypi_unauthorized_file_operation_behavior {
    meta:
        description = "Detects unauthorized file manipulation behavior in Python packages."
        author = "qwen2.5-coder:14b"
        date = "2026-08-04"
        reference = ""

    strings:
        $read_file = /open\([^,]+,\s*['"]r['"]/ nocase
        $write_file = /open\([^,]+,\s*['"]w['"]/ nocase
        $append_file = /open\([^,]+,\s*['"]a['"]/ nocase
        $delete_file = /os\.remove\(/ nocase
        $copy_file = /shutil\.copy\(/ nocase
        $move_file = /shutil\.move\(/ nocase

    condition:
        any of ($read_file, $write_file, $append_file, $delete_file, $copy_file, $move_file)
}
