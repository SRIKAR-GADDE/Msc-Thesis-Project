rule pypi_encoding_obfuscation_api_usage
{
    meta:
        description = "Detects encoding/decoding/encryption API usage combined with eval/exec indicative of obfuscated malicious payloads"
        author = "gpt-oss:20b"
        date = "2026-08-04"
        reference = ""

    strings:
        $base64_decode   = /(?is)base64\.b64decode\(.*\)/ nocase
        $binascii_unhex  = /(?is)binascii\.unhexlify\(.*\)/ nocase
        $zlib_decompress = /(?is)zlib\.decompress\(.*\)/ nocase
        $gzip_decompress = /(?is)gzip\.decompress\(.*\)/ nocase

        $eval_exec = /(?is)(?:eval|exec)\(.*\)/ nocase

    condition:
        (
            ($base64_decode and $eval_exec)
            or ($binascii_unhex and $eval_exec)
            or ($zlib_decompress and $eval_exec)
            or ($gzip_decompress and $eval_exec)
        )
}
