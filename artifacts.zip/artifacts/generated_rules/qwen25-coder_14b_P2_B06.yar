rule pypi_command_execution_behavior {
    meta:
        description = "Detects malicious package behaviour involving execution of operating system commands, shell instructions, or external binaries after installation or during package execution."
        author = "qwen2.5-coder:14b"
        date = "2026-08-04"
        reference = ""

    strings:
        $subprocess_call = /subprocess\.(call|check_call|check_output|run)\s*\(/ nocase
        $os_system_call = /os\.system\s*\(/ nocase
        $os_popen_call = /os\.popen\s*\(/ nocase
        $shutil_which_call = /shutil\.which\s*\(/ nocase
        $subprocess_shell_true = /shell=True/ nocase
        $subprocess_shell_false = /shell=False/ nocase

    condition:
        any of ($subprocess_call, $os_system_call, $os_popen_call, $shutil_which_call) and not all of ($subprocess_shell_false)
}
