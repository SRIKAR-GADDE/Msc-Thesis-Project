rule pypi_file_operation_api_usage {
    meta:
        description = "Detects suspicious use of file handling APIs that may allow malicious packages to read, modify, create, or delete local files."
        author = "qwen2.5-coder:7b"
        date = "2026-08-04"
        reference = ""

    strings:
        $open = "open("
        $read = "read()"
        $write = "write("
        $delete = "os.remove("

    condition:
        any of ($open, $read, $write, $delete) and
        filesize < 100KB and
        not any of (pe, elf, cuckoo)
}
