rule pypi_remote_control_behavior (phase: 2)
{
    meta:
        description = "Detects malicious package behaviour establishing remote control functionality."
        author = "llama3.1:8b"
        date = "2026-08-04"
        reference = ""

    strings:
        $cmd_and_ctl = /import requests|import socket|import urllib|import http|import https|import ssl/
        $remote_cmd = /subprocess\.call\(|os\.system\(|exec\(/
        $persistent_interaction = /threading\.Thread\(|queue\.Queue\(|multiprocessing\.Process\(|socket\.create_connection\(|requests\.Session\(|urllib\.request\.Request\(|http\.client\.HTTPConnection\(|https\.client\.HTTPSConnection/

    condition:
        ($cmd_and_ctl or $remote_cmd or $persistent_interaction) and not (import re|import sys|import os)
}
