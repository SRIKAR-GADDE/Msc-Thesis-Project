Meta
-----
Description
---------
Detects Python package source code capable of dynamically executing generated or retrieved code during runtime.

Author
------
lama3.2:1b

Date
----
2026-08-04

Reference
----------
None
