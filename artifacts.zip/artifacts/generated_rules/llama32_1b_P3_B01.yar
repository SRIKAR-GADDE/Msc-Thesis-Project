Meta
{
    description = "Detects Python package source code that uses networking capabilities to communicate with external servers";
    author     = "lama3.2:1b";
    date       = "2026-08-04";
    reference  = "";
}

pypi_network_api_usage
{
    type = network_api_usage;
    file_type = python;
    class {
        http_client
        socket_communication
        url_requests
        remote_connections
        network_communication_patterns
    }
}
