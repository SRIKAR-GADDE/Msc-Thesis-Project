rule pypi_remote_control_behavior {
    meta:
        description = "Detects malicious package behaviour establishing remote control functionality, including command-and-control communication channels, remote command handling, or persistent external interaction."
        author = "qwen2.5-coder:7b"
        date = "2026-08-04"
        reference = ""

    strings:
        $http_request = /GET|POST|PUT|DELETE|HEAD/
        $socket_connect = /socket\.connect\(/i
        $subprocess_call = /subprocess\.call\(/i
        $os_system = /os\.system\(/i
        $urlopen = /urllib2\.urlopen\(|urllib\.request\.urlopen\(/i

    condition:
        any of ($http_request, $socket_connect, $subprocess_call, $os_system, $urlopen)
}
