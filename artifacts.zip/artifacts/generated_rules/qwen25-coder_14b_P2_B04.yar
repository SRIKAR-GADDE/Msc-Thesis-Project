rule pypi_encoding_obfuscation_api_usage {
    meta:
        description = "Detects encoding, decoding, encryption, or transformation functions commonly used to conceal malicious payloads, commands, or downloaded content inside Python packages."
        author = "qwen2.5-coder:14b"
        date = "2026-08-04"
        reference = ""

    strings:
        $base64_encode = /base64\.encode\(/ nocase
        $base64_decode = /base64\.decode\(/ nocase
        $xor_encrypt = /\b\w+\.\w+\.xor\(/ nocase
        $rot13 = /\brot13\b/ nocase
        $zlib_compress = /zlib\.compress\(/ nocase
        $zlib_decompress = /zlib\.decompress\(/ nocase
        $gzip_compress = /gzip\.compress\(/ nocase
        $gzip_decompress = /gzip\.decompress\(/ nocase
        $aes_encrypt = /\baes\.encrypt\(/ nocase
        $aes_decrypt = /\baes\.decrypt\(/ nocase
        $rsa_encrypt = /\brsa\.encrypt\(/ nocase
        $rsa_decrypt = /\brsa\.decrypt\(/ nocase

    condition:
        any of ($base64*) or any of ($xor_encrypt) or any of ($rot13) or any of ($zlib*) or any of ($gzip*) or any of ($aes*) or any of ($rsa*)
}
