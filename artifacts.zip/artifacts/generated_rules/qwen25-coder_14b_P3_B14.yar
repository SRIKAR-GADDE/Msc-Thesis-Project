rule pypi_trace_erasure_evasion {
    meta:
        description = "Detects attempts to remove evidence after malicious execution, including deletion of dropped files, cleanup commands, temporary payload removal, or destruction of execution traces."
        author = "qwen2.5-coder:14b"
        date = "2026-08-04"
        reference = ""

    strings:
        $del_cmd_1 = /os\.remove\(/ nocase
        $del_cmd_2 = /shutil\.rmtree\(/ nocase
        $del_cmd_3 = /os\.unlink\(/ nocase
        $cleanup_cmd_1 = /\bshlex\b.*\bcleanup\b/ nocase
        $cleanup_cmd_2 = /\bsubprocess\b.*\bclean\b/ nocase
        $temp_cleanup_1 = /\btempfile\b.*\bdel\b/ nocase
        $temp_cleanup_2 = /\btempfile\b.*\bremove\b/ nocase

    condition:
        (3 of ($del_cmd_*)) and (2 of ($cleanup_cmd_* or $temp_cleanup_*))
}
