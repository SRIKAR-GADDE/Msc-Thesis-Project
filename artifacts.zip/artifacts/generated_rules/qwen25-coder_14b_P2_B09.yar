rule pypi_code_execution_behavior {
    meta:
        description = "Detects execution of injected, downloaded, or dynamically generated Python code through runtime evaluation or execution mechanisms."
        author = "qwen2.5-coder:14b"
        date = "2026-08-04"
        reference = ""

    strings:
        $eval_call = /eval\s*\(/ nocase
        $exec_call = /exec\s*\(/ nocase
        $compile_call = /compile\s*\(/ nocase
        $os_system_call = /os\.system\s*\(/ nocase
        $subprocess_popen_call = /subprocess\.Popen\s*\(/ nocase
        $subprocess_check_output_call = /subprocess\.check_output\s*\(/ nocase
        $subprocess_run_call = /subprocess\.run\s*\(/ nocase

    condition:
        any of ($eval_call, $exec_call, $compile_call, $os_system_call, $subprocess_popen_call, $subprocess_check_output_call, $subprocess_run_call)
}
