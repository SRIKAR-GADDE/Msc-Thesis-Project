rule pypi_remote_control_behavior {
    meta:
        description = "Detects malicious package behavior establishing remote control functionality."
        author = "qwen2.5-coder:14b"
        date = "2026-08-04"
        reference = ""

    strings:
        $import_socket = /import\s+socket/
        $import_subprocess = /import\s+subprocess/
        $import_os = /import\s+os/
        $command_execution = /\b(subprocess\.call|subprocess\.check_output)\s*\(/
        $remote_connection = /\bsocket\.create_connection\b/
        $persistent_interaction = /\bwhile\s+True\b/

    condition:
        all of ($import_socket, $import_subprocess) and any of ($command_execution, $remote_connection, $persistent_interaction)
}
