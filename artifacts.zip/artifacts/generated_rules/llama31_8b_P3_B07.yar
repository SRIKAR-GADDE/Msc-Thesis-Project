rule pypi_information_stealing_behavior {
  strings:
    $collect_credentials = /import re|import requests|import socket|import os|import pwd|import grp/
    $env_var_access = /os\.environ\[\w+\]|pwd\.getpwuid\(os\.geteuid\(\)\)|grp\.getgrgid\(os\.getegid\(\)\)/
    $browser_data_access = /import webbrowser|import selenium|import pyautogui/
    $system_info_access = /import platform|import psutil|import sys/
    $secret_storage_access = /import pickle|import json|import sqlite3/

  condition:
    any of them
}
