rule pypi_unauthorized_file_operation_behavior {
    meta:
        description = "Detects unauthorized file operations in Python packages."
        author = "qwen2.5-coder:7b"
        date = "2026-08-04"
        reference = ""

    strings:
        $open = "open("
        $read = "read()"
        $write = "write("
        $copy = "shutil.copy(" or "copyfile("
        $delete = "os.remove(" or "unlink("

    condition:
        any of ($*) and
        not any of (
            $open in ("import os", "from os import open"),
            $read in ("import os", "from os import read"),
            $write in ("import os", "from os import write"),
            $copy in ("import shutil", "from shutil import copy", "from shutil import copyfile"),
            $delete in ("import os", "from os import remove", "from os import unlink")
        )
}
