rule pypi_python_sandbox_escape {
    meta:
        description = "Detects techniques intended to bypass static analysis or restricted execution environments using dynamic imports, reflection, compilation, execution chains, or obfuscated runtime behaviour."
        author = "qwen2.5-coder:14b"
        date = "2026-08-04"
        reference = ""

    strings:
        $dynamic_import = /__import__\s*\(/ nocase
        $reflection = /\.__getattr__\s*\(/ or /\.__setattr__\s*\(/ or /\.__getattribute__\s*\(/ nocase
        $compilation = /compile\s*\(/ or /exec\s*\(/ or /eval\s*\(/ nocase
        $execution_chain = /\.\__call__\s*\(/ or /\.\__init__\s*\(/ or /\.\__new__\s*\(/ nocase
        $obfuscation = /chr\s*\(\d+\)\.join\s*\(/ or /bytes\.fromhex\s*\(/ or /base64\.b64decode\s*\(/ nocase

    condition:
        any of ($dynamic_import, $reflection, $compilation, $execution_chain, $obfuscation)
}
