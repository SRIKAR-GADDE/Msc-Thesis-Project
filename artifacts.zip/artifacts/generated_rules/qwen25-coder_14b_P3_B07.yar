rule pypi_information_stealing_behavior {
    meta:
        description = "Detects behaviour associated with collecting sensitive information such as credentials, tokens, environment variables, browser data, system information, or other locally stored secrets."
        author = "qwen2.5-coder:14b"
        date = "2026-08-04"
        reference = ""

    strings:
        $env_var_access = /os\.environ\['(PASSWORD|TOKEN|SECRET|API_KEY|USERNAME)'?\]/
        $file_read_credentials = /open\(.*\.(db|sqlite3|json|ini|conf)\)/
        $keylogger_pattern = /\b(keylogger|keystroke|log_keys|record_keystrokes)\b/
        $screenshot_capture = /\bscreen\.shot\b|\bcapture_screen\b/
        $clipboard_access = /\bpyperclip\.paste\b|\bpyautogui\.hotkey\('ctrl', 'c'\)/
        $system_info_gathering = /\bpsutil\.(cpu_percent|virtual_memory|disk_usage)\b/

    condition:
        all of ($env_var_access, $file_read_credentials) or
        any of ($keylogger_pattern, $screenshot_capture, $clipboard_access, $system_info_gathering)
}
