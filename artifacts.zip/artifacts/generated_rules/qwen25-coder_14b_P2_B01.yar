rule pypi_network_api_usage {
    meta:
        description = "Detects Python package source code that uses networking capabilities to communicate with external servers."
        author = "qwen2.5-coder:14b"
        date = "2026-08-04"
        reference = ""

    strings:
        $http_request = /requests\.[a-zA-Z_]+\(/ nocase
        $urllib_request = /urllib\.request\.[a-zA-Z_]+\(/ nocase
        $socket_connect = /socket\.connect\(/ nocase
        $socket_create_connection = /socket\.create_connection\(/ nocase
        $httpx_request = /httpx\.[a-zA-Z_]+\(/ nocase
        $aiohttp_client = /aiohttp\.ClientSession\(/ nocase

    condition:
        any of ($http_request, $urllib_request, $socket_connect, $socket_create_connection, $httpx_request, $aiohttp_client)
}
