rule pypi_trace_erasure_evasion {
    meta:
        description = "Detects attempts to remove evidence after malicious execution in Python source code."
        author = "qwen2.5-coder:14b"
        date = "2026-08-04"
        reference = ""

    strings:
        $del_cmd = /os\.remove\(/ nocase
        $rmdir_cmd = /shutil\.rmtree\(/ nocase
        $unlink_cmd = /os\.unlink\(/ nocase
        $cleanup_func = /\bdef\s+clean_up\b/ nocase

    condition:
        any of ($del_cmd, $rmdir_cmd, $unlink_cmd) or $cleanup_func
}
