Meta
---
Description: Behavioural detection of information stealing patterns in PyPI packages
Author: llama3.2:1b
Date: 2026-08-04
Reference: None

pypi_information_stealing_behavior
{
    type = behavior
    source 
        {
            api = python
            language = python
            os = unix
            osx
            win
        }
    condition 
        {
            $api == "requests"
            $os == "unix"
            $language == "python"
            $osx || $win
            $browser_data || $system_info || $token || $credentials || $environment_variables
        }
}
