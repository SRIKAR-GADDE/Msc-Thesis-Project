rule pypi_network_api_usage {
    meta:
        description = "Detects Python package source code that uses networking capabilities to communicate with external servers."
        author = "qwen2.5-coder:14b"
        date = "2026-08-04"
        reference = ""

    strings:
        $http_client_import = /import\s+requests/
        $socket_import = /import\s+socket/
        $urllib_import = /import\s+urllib\./
        $http_request_pattern = /\brequests\.get\b|\brequests\.post\b|\brequests\.put\b|\brequests\.delete\b/
        $socket_connect_pattern = /\bsocket\.connect\b/
        $url_open_pattern = /\burllib\.request\.urlopen\b/

    condition:
        any of ($http_client_import, $socket_import, $urllib_import) and
        any of ($http_request_pattern, $socket_connect_pattern, $url_open_pattern)
}
