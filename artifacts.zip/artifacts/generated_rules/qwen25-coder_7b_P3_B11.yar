rule pypi_indirect_import_evasion {
    meta:
        description = "Detects malicious behaviour where harmful functionality is introduced through package dependencies, installation hooks, or indirect imports instead of being directly contained in the main package source."
        author = "qwen2.5-coder:7b"
        date = "2026-08-04"
        reference = ""

    strings:
        $a = "import os"
        $b = "import sys"
        $c = "import subprocess"
        $d = "from setuptools import setup, find_packages"
        $e = "from distutils.core import setup"

    condition:
        any of ($a, $b, $c) and
        (file.exists("setup.py") or file.exists("setup.cfg")) and
        not any of ($d, $e)
}
