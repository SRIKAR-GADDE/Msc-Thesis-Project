rule pypi_command_execution_behavior {
    meta:
        description = "Detects malicious package behavior involving execution of operating system commands, shell instructions, or external binaries after installation or during package execution."
        author = "qwen2.5-coder:14b"
        date = "2026-08-04"
        reference = ""

    strings:
        $cmd_exec_1 = /os\.system\(/ nocase
        $cmd_exec_2 = /subprocess\.call\(/ nocase
        $cmd_exec_3 = /subprocess\.run\(/ nocase
        $cmd_exec_4 = /subprocess\.Popen\(/ nocase
        $shell_exec_1 = /\!?\s*sh\s+-c\s+/ nocase
        $shell_exec_2 = /\!?\s*bash\s+-c\s+/ nocase

    condition:
        any of ($cmd_exec*) or any of ($shell_exec*)
}
