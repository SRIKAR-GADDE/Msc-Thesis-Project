rule pypi_python_sandbox_escape {
  strings:
    $dynamic_import = "import.*\("
    $reflection = "getattr|hasattr|setattr|delattr"
    $compilation = "compile|eval|exec"
    $execution_chain = "subprocess|os.system|os.popen"
    $obfuscated_runtime = "base64|hex|binascii|re|json"

  condition:
    ($dynamic_import or $reflection or $compilation or $execution_chain or $obfuscated_runtime) and
    not (all of ($dynamic_import, $reflection, $compilation, $execution_chain, $obfuscated_runtime))
}
