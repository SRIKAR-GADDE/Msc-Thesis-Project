rule pypi_platform_targeting_evasion {
    meta:
        description = "Detects malicious packages that identify the operating system platform and execute platform-specific payloads or behaviour targeting Windows, Linux, or macOS environments."
        author = "qwen2.5-coder:14b"
        date = "2026-08-04"
        reference = ""

    strings:
        $platform_check_win = /import\s+platform.*platform\.system\(\)\s*==\s*"Windows"/
        $platform_check_linux = /import\s+platform.*platform\.system\(\)\s*==\s*"Linux"/
        $platform_check_macos = /import\s+platform.*platform\.system\(\)\s*==\s*"Darwin"/

    condition:
        any of ($platform_check*)
}
