Meta
---
Description: Behavioural detection of PyPI remote control functionality
Author: llama3.2:1b
Date: 2026-08-04
Reference: -

pypi_remote_control_behavior
{
    type = behavior
    source \
        https://raw.githubusercontent.com/pypa/requests/master/requests/__init__.py \
        https://github.com/python/cpython/blob/main/Lib/weakref.py \
        https://github.com/python/cpython/blob/main/Lib/traceback.py \
        https://github.com/python/cpython/blob/main/Lib/heapq.py \
    conditions \
        command_and_control_communication_channel \
        remote_command_handling \
        persistent_external_interaction
}
