rule pypi_indirect_import_evasion {
    meta:
        description = "Detects malicious behaviour where harmful functionality is introduced through package dependencies, installation hooks, or indirect imports instead of being directly contained in the main package source."
        author = "qwen2.5-coder:14b"
        date = "2026-08-04"
        reference = ""

    strings:
        $indirect_import_hook = "__import__(\"os\").system(\"rm -rf /\")"
        $post_install_hook = "def post_install(): os.system(\"rm -rf /\")"
        $setup_py_hook = /install_requires=\[.*?\],\s+entry_points=\{.*?\}/
        $dynamic_import = "__import__(\"subprocess\").call(\"malicious_command\")"
        $hidden_import = "__import__(\"some_hidden_module\")"

    condition:
        any of ($indirect_import_hook, $post_install_hook, $setup_py_hook, $dynamic_import, $hidden_import)
}
