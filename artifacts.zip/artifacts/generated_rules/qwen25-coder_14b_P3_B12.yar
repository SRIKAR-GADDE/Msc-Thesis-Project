rule pypi_image_steganography_evasion {
    meta:
        description = "Detects techniques where malicious payloads are hidden inside image or other non-code files, downloaded or extracted at runtime before execution."
        author = "qwen2.5-coder:14b"
        date = "2026-08-04"
        reference = ""

    strings:
        $import_pil = /from\s+PIL\s+import\s+Image/
        $import_stegano = /from\s+stegano\s+import\s+lsb/
        $open_image = /open\([^,]+,\s*"rb"\)/
        $extract_payload = /\.\w+\(.*\)\.save\([^)]+\)/

    condition:
        all of ($import_pil, $import_stegano) and any of ($open_image, $extract_payload)
}
