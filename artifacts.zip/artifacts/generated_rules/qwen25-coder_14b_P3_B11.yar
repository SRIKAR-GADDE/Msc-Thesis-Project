rule pypi_indirect_import_evasion {
    meta:
        description = "Detects malicious behaviour where harmful functionality is introduced through package dependencies, installation hooks, or indirect imports instead of being directly contained in the main package source."
        author = "qwen2.5-coder:14b"
        date = "2026-08-04"
        reference = ""

    strings:
        $indirect_import_hook = "__import__('os').system('rm -rf /')"
        $post_install_script = "def post_install(lib, pkg_resources): os.system('malicious_command')"
        $setup_py_hooks = "from setuptools import setup; setup(..., cmdclass={'install': CustomInstall})"
        $dynamic_imports = "__import__(module_name)"
        $hidden_imports = "hiddenimports=['malicious_module']"

    condition:
        any of ($indirect_import_hook, $post_install_script, $setup_py_hooks, $dynamic_imports, $hidden_imports)
}
