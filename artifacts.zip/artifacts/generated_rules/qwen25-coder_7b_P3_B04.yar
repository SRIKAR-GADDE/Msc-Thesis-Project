rule pypi_encoding_obfuscation_api_usage {
    meta:
        description = "Detects encoding, decoding, encryption, or transformation functions commonly used to conceal malicious payloads, commands, or downloaded content inside Python packages."
        author = "qwen2.5-coder:7b"
        date = "2026-08-04"
        reference = ""

    strings:
        $a1 = /base64\.encode/
        $a2 = /base64\.decode/
        $a3 = /cryptography\.fernet\./
        $a4 = /hashlib\.(md5|sha1|sha256|sha512)/
        $a5 = /zlib\.compress/
        $a6 = /zlib\.decompress/
        $a7 = /gzip\.GzipFile/
        $a8 = /bz2\.BZ2Compressor/
        $a9 = /bz2\.BZ2Decompressor/
        $a10 = /lzma\.LZMACompressor/
        $a11 = /lzma\.LZMADecompressor/

    condition:
        any of ($a*)
}
