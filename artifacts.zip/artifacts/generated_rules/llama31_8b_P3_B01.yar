$pypi_network_api_usage =
  (
    (import "http.client") or
    (import "socket") or
    (import "urllib.request") or
    (import "requests") or
    (import "pycurl")
  ) and
  (
    (string "connect" in ($1) and not string "localhost" in ($1)) or
    (string "send" in ($1) and not string "sys.stdout" in ($1)) or
    (string "recv" in ($1) and not string "sys.stdin" in ($1))
  )

meta:
  description = "Detects Python package source code that uses networking capabilities to communicate with external servers."
  author = "llama3.1:8b"
  date = "2026-08-04"
  reference = ""
