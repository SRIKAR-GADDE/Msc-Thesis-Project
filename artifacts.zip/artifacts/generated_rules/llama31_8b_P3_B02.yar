$pypi_file_operation_api_usage =
  (regmatch("os\.access") or regmatch("os\.chmod") or regmatch("os\.chown") or
   regmatch("os\.lchown") or regmatch("os\.link") or regmatch("os\.mkdir") or
   regmatch("os\.mknod") or regmatch("os\.open") or regmatch("os\.read") or
   regmatch("os\.rename") or regmatch("os\.rmdir") or regmatch("os\.symlink") or
   regmatch("os\.truncate") or regmatch("os\.unlink") or regmatch("os\.write"))

meta:
  description = "Detects suspicious use of file handling APIs in PyPI packages"
  author = "llama3.1:8b"
  date = "2026-08-04"
  reference = ""
