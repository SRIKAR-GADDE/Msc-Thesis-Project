rule pypi_command_execution_behavior {
  strings:
    $os_imports = /import (?:os|subprocess|commands|pty|popen)/i
    $shell_exec = /exec\(\s*\$(.*?)\s*\)/i or /system\(\s*(.*?)\s*\)/i
    $external_binaries = /subprocess\.call\((.*?),(.*?)\)/i

  condition:
    any of them
}
