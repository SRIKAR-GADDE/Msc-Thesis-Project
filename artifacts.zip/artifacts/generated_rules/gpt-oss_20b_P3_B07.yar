rule pypi_information_stealing_behavior
{
    meta:
        description = "Detects behaviour associated with collecting sensitive information such as credentials, tokens, environment variables, browser data, system information, or other locally stored secrets."
        author = "gpt-oss:20b"
        date = "2026-08-04"
        reference = ""

    strings:
        $env_get      = /os\.getenv\(/ nocase
        $env_environ  = /os\.environ\.get\(/ nocase
        $keyring_get  = /keyring\.get_password\(/ nocase
        $ssh_file     = /[\\\/]\.ssh[\\\/]id_[rsa]/ nocase
        $git_config   = /[\\\/]\.gitconfig/ nocase
        $cred_file    = /credentials|credential|passwords?\.txt|passphrase/i
        $browser_path = /(?:Chrome|Chromium|Firefox|Edge)[\\\/]/ nocase

    condition:
        (
            ((count($env_get) + count($env_environ)) > 0) +
            (count($keyring_get) > 0) +
            ((count($ssh_file) + count($git_config) + count($cred_file)) > 0) +
            (count($browser_path) > 0)
        ) >= 2
}
