rule pypi_dynamic_execution_api_usage {
    meta:
        description = "Detects Python package source code capable of dynamically executing generated or retrieved code during runtime."
        author = "qwen2.5-coder:14b"
        date = "2026-08-04"
        reference = ""

    strings:
        $dynamic_exec_1 = /exec\(.+\)/
        $dynamic_exec_2 = /eval\(.+\)/
        $dynamic_exec_3 = /compile\(.+\)/
        $dynamic_import_1 = /__import__\(.+\)/
        $dynamic_import_2 = /importlib\.import_module\(.+\)/

    condition:
        any of ($dynamic_exec*) or any of ($dynamic_import*)
}
