Meta
-----
Description
---------
Detects attempts to remove evidence after malicious execution, including deletion of dropped files, cleanup commands, temporary payload removal, or destruction of execution traces.

Author
------
lama3.2:1b

Date
------
2026-08-04

Reference
----------
None
