rule pypi_process_api_usage
{
    meta:
        description = "Detects Python APIs capable of spawning OS processes or executing shell commands"
        author = "gpt-oss:20b"
        date = "2026-08-04"
        reference = ""

    strings:
        // Imports that bring process execution capabilities
        $subprocess_import = /import\s+subprocess/
        $os_import          = /import\s+os/

        // Direct calls to OS-level command execution
        $os_system_call     = /os\.system\(/ 
        $os_popen_call      = /os\.popen\(/ 
        $os_exec_call       = /os\.exec[^\(]*\(/ 
        $os_spawn_call      = /os\.spawn[^\(]*\(/ 

        // Subprocess API usage
        $subprocess_popen_call     = /subprocess\.Popen\(/ 
        $subprocess_call_call      = /subprocess\.call\(/ 
        $subprocess_run_call       = /subprocess\.run\(/ 
        $subprocess_check_output_call = /subprocess\.check_output\(/ 
        $subprocess_getoutput_call = /subprocess\.getoutput\(/ 

        // Shell=True usage in subprocess
        $subprocess_popen_shell   = /subprocess\.Popen\([^)]*shell\s*=\s*True[^)]*\)/ 
        $subprocess_run_shell     = /subprocess\.run\([^)]*shell\s*=\s*True[^)]*\)/

    condition:
        (any of ($subprocess_import, $os_import)) and
        (
            any of ($os_system_call, $os_popen_call, $os_exec_call, $os_spawn_call,
                    $subprocess_popen_call, $subprocess_call_call, $subprocess_run_call,
                    $subprocess_check_output_call, $subprocess_getoutput_call)
        )
}
