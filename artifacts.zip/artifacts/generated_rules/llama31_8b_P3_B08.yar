rule pypi_unauthorized_file_operation_behavior {
  strings:
    $read_file = /import (re|os)\.path\./ or
                 /open\(.*?\, 'r'\) or
                 /with open\(.*?\, 'r'\) as /
    $write_file = /import (re|os)\.path\./ or
                  /open\(.*?\, 'w'\) or
                  /with open\(.*?\, 'w'\) as /
    $modify_file = /import (re|os)\.path\./ or
                   /open\(.*?\, 'r+'\) or
                   /with open\(.*?\, 'r+'\) as /
    $copy_file = /import shutil/ or
                 /shutil\.copy\(.*?\) or
                 /shutil\.copy2\(.*?\)/
    $delete_file = /import (re|os)\.path\./ or
                   /os\.remove\(.*?\) or
                   /os\.unlink\(.*?\)/

  condition:
    any of them
}
