rule pypi_unauthorized_file_operation_behavior {
    meta:
        description = "Detects unauthorized file manipulation behaviour including reading, writing, modification, copying, or deletion of local files."
        author = "qwen2.5-coder:14b"
        date = "2026-08-04"
        reference = ""

    strings:
        $read_file = /open\([^,]+,\s*['"]r['"]/i
        $write_file = /open\([^,]+,\s*['"]w['"]/i
        $append_file = /open\([^,]+,\s*['"]a['"]/i
        $delete_file = /os\.remove\(/i
        $copy_file = /shutil\.copy\(/i
        $move_file = /shutil\.move\(/i

    condition:
        any of ($read_file, $write_file, $append_file) and (any of ($delete_file, $copy_file, $move_file))
}
