rule pypi_dynamic_execution_api_usage {
    meta:
        description = "Detects Python package source code capable of dynamically executing generated or retrieved code during runtime."
        author = "qwen2.5-coder:14b"
        date = "2026-08-04"
        reference = ""

    strings:
        $exec_dynamic_code_1 = /__import__\(['\"]os['\"]\)\.system\(.*\)/
        $exec_dynamic_code_2 = /eval\(.+\)/
        $exec_dynamic_code_3 = /exec\(.+\)/
        $exec_dynamic_code_4 = /subprocess\.call\(.*\)/
        $exec_dynamic_code_5 = /subprocess\.run\(.*\)/
        $exec_dynamic_code_6 = /os\.popen\(.*\)/

    condition:
        any of ($exec_dynamic_code*)
}
